# VCS Extra Duty Scraper

Python + Selenium script to extract Extra Duty job data from the VCS Software site into a CSV for further analysis (Power Query, Power BI, etc.).

## Purpose

- Attach to an already logged-in Chrome session.
- Read the Extra Duty job grid for a given date range.
- Export all visible rows with:
  - Job #
  - Description
  - Date
  - Times
  - Customer
  - Address
  - Immediate Award
  - Status

## Requirements

- Windows 10/11
- Google Chrome (up to date)
- Python 3.x
- Installed packages:
  - `selenium`
  - `pandas`

Install packages:

```
pip install selenium pandas
```


## File Locations

- Script folder:
  - `C:\Users\carucci_r\OneDrive - City of Hackensack\RAC\Extra_Duty\scripts`
- Main script:
  - `vcs_extra_duty_scrape.py`
- Output CSV:
  - `vcs_extra_duty_jobs.csv` (or `vcs_extra_duty_jobs_2025_Q4.csv` in some versions)

## How to Run

1. Close all existing Chrome windows.
2. Start Chrome in remote debugging mode:

   ```
   chrome.exe --remote-debugging-port=9222 --user-data-dir="C:\ChromeDebug"
   ```


3. In that Chrome window:
   - Log in to VCS.
   - Navigate to:
     - `https://app10.vcssoftware.com/extra-duty-signup`
   - Set the desired Start and End Date (e.g., 10/01/2025–12/31/2025).

4. In Command Prompt:

   ```
   cd "C:\Users\carucci_r\OneDrive - City of Hackensack\RAC\Extra_Duty\scripts"
   python vcs_extra_duty_scrape.py
   ```


5. After the script runs:
   - Check `vcs_extra_duty_jobs*.csv` in the same folder.
   - Open in Excel or Power BI / Power Query.

## Date Range Control

- The script includes a helper function `set_date_range(start_date, end_date)`.
- To scrape a custom range (e.g., full year 2025), make sure this line is enabled in the script:

```
set_date_range("01/01/2025", "12/31/2025")
```


If disabled, the script will use whatever date range is already set in the UI.

## Notes

- The script attaches to an existing Chrome session using `debuggerAddress=127.0.0.1:9222`.
- It avoids unnecessary page reloads by checking `driver.current_url` before calling `driver.get()`.
- The grid is located using robust locators (table/div/role-based) instead of brittle text searches.