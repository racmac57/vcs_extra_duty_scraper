# Summary – VCS Extra Duty Scraper

## What This Script Does

- Connects to an already-authenticated Chrome session using Selenium.
- Reads the Extra Duty job grid from the VCS Software "Extra Duty Signup" page.
- Captures all visible rows and exports them to a CSV file for analysis and reporting.

## Why It Was Needed

- The VCS grid is rendered by a modern web app, so simple `pandas.read_html()` does not work.
- The job list is not a basic static `<table>`; it needs a real browser (Selenium) to:
  - Render the page.
  - Apply date filters.
  - Read the grid structure.

## How It Works (Short Version)

1. Start Chrome with remote debugging.
2. Log in and manually go to the Extra Duty grid with the desired date range.
3. Run the Python script:
   - Attaches to Chrome.
   - Locates the grid using resilient locators (table/div/role-based).
   - Iterates through each row and cell.
   - Writes a CSV with the core job fields.

## Current Output

- CSV file with one row per job:
  - `Job #`
  - `Description`
  - `Date`
  - `Times`
  - `Customer`
  - `Address`
  - `Immediate Award`
  - `Status`

This CSV can be:
- Loaded into Power Query for ETL.
- Used in Power BI for dashboards.
- Joined with other CAD/RMS data for operational analysis.
