from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
import pandas as pd
import time
import os

# Attach Selenium to the running Chrome debug session
options = webdriver.ChromeOptions()
options.add_experimental_option("debuggerAddress", "127.0.0.1:9222")
driver = webdriver.Chrome(options=options)

wait = WebDriverWait(driver, 20)

# Check if we're already on the page; if not, navigate there
current_url = driver.current_url
print(f"Current URL: {current_url}")

if "app10.vcssoftware.com/extra-duty-signup" not in current_url:
    print("Navigating to Extra Duty page...")
    driver.get("https://app10.vcssoftware.com/extra-duty-signup")
    time.sleep(2)  # Allow page to stabilize after navigation
else:
    print("Already on Extra Duty page - skipping navigation")

# Optional: Set date range programmatically (commented out by default)
# Call this function if you want to change the date range before scraping
def set_date_range(start_date, end_date):
    """
    Set the Start Date and End Date fields.
    Args:
        start_date: String in format "MM/DD/YYYY" (e.g., "01/01/2025")
        end_date: String in format "MM/DD/YYYY" (e.g., "12/31/2025")
    """
    print(f"Setting date range: {start_date} to {end_date}")

    # Find Start Date input - adjust selector if needed
    start_input = wait.until(
        EC.presence_of_element_located((By.XPATH, "//input[contains(@placeholder, 'Start') or contains(@aria-label, 'Start')]"))
    )
    start_input.clear()
    start_input.send_keys(start_date)
    start_input.send_keys(Keys.TAB)  # Trigger any change events

    # Find End Date input
    end_input = driver.find_element(By.XPATH, "//input[contains(@placeholder, 'End') or contains(@aria-label, 'End')]")
    end_input.clear()
    end_input.send_keys(end_date)
    end_input.send_keys(Keys.TAB)

    time.sleep(1)  # Wait for grid to refresh

# Uncomment to set full year range:
# set_date_range("01/01/2025", "12/31/2025")

# Wait for the grid to be present
# Strategy: Look for the table/grid container by common grid attributes
# Most web grids use: <table>, <div role="grid">, or elements with class names like "grid", "table", "data-grid"
print("\nLocating grid container...")

# Try multiple strategies to find the grid
grid_container = None
strategies = [
    # Strategy 1: Look for a table element
    (By.TAG_NAME, "table"),
    # Strategy 2: Look for div with role="grid"
    (By.XPATH, "//div[@role='grid']"),
    # Strategy 3: Look for common grid class names
    (By.XPATH, "//div[contains(@class, 'grid') or contains(@class, 'table')]"),
    # Strategy 4: Look for the specific column header "Job #"
    (By.XPATH, "//th[contains(text(), 'Job #')] | //div[contains(text(), 'Job #')]"),
]

for i, (by, locator) in enumerate(strategies, 1):
    try:
        print(f"  Trying strategy {i}: {by}='{locator[:50]}...'")
        element = wait.until(EC.presence_of_element_located((by, locator)))
        print(f"  ✓ Found element: <{element.tag_name}> with classes: {element.get_attribute('class')}")

        # If we found a header, go up to find the table/grid container
        if element.tag_name in ['th', 'div'] and 'Job #' in element.text:
            # Navigate up to find the table or grid container
            for _ in range(5):  # Try up to 5 parent levels
                parent = element.find_element(By.XPATH, "./..")
                if parent.tag_name in ['table', 'tbody'] or 'grid' in parent.get_attribute('class').lower():
                    grid_container = parent
                    print(f"  ✓ Found grid container: <{grid_container.tag_name}>")
                    break
                element = parent
        else:
            grid_container = element

        if grid_container:
            break
    except Exception as e:
        print(f"  ✗ Strategy {i} failed: {str(e)[:60]}")
        continue

if not grid_container:
    print("\n❌ Could not locate grid. Dumping page source to debug...")
    with open("page_source_debug.html", "w", encoding="utf-8") as f:
        f.write(driver.page_source)
    print("Saved page source to page_source_debug.html")
    driver.quit()
    raise SystemExit("Grid not found. Check page_source_debug.html")

# Extract all rows from the grid
print("\nExtracting grid rows...")

# Find all rows (try both <tr> for tables and div-based rows)
rows = grid_container.find_elements(By.XPATH, ".//tr[td] | .//div[contains(@role, 'row')]")
print(f"Found {len(rows)} data rows")

if len(rows) == 0:
    print("No rows found. Trying alternative row selectors...")
    # Some grids use different structures
    rows = driver.find_elements(By.XPATH, "//tr[td] | //div[contains(@class, 'row') and contains(@class, 'data')]")
    print(f"Found {len(rows)} rows with alternative selector")

# Debug: Print first row's HTML structure
if rows:
    print("\n--- First Row Structure (for debugging) ---")
    first_row_html = rows[0].get_attribute('outerHTML')[:500]
    print(first_row_html)
    print("--- End Structure ---\n")

# Extract data from each row
data = []
for idx, row in enumerate(rows):
    try:
        # Get all cells in this row (try both <td> and div-based cells)
        cells = row.find_elements(By.XPATH, ".//td | .//div[contains(@role, 'cell') or contains(@class, 'cell')]")

        if len(cells) < 7:  # We expect at least 7 columns (Job #, Desc, Date, Times, Customer, Address, Award, Status)
            continue

        # Extract text from each cell
        cell_texts = [cell.text.strip() for cell in cells]

        # Map to expected columns (adjust indices if needed based on actual grid structure)
        # Expected columns: Job #, Description, Date, Times, Customer, Address, Immediate Award, Status
        row_data = {
            "Job #": cell_texts[0] if len(cell_texts) > 0 else "",
            "Description": cell_texts[1] if len(cell_texts) > 1 else "",
            "Date": cell_texts[2] if len(cell_texts) > 2 else "",
            "Times": cell_texts[3] if len(cell_texts) > 3 else "",
            "Customer": cell_texts[4] if len(cell_texts) > 4 else "",
            "Address": cell_texts[5] if len(cell_texts) > 5 else "",
            "Immediate Award": cell_texts[6] if len(cell_texts) > 6 else "",
            "Status": cell_texts[7] if len(cell_texts) > 7 else "",
        }

        data.append(row_data)

        # Debug: Print first 3 rows
        if idx < 3:
            print(f"Row {idx + 1}: {row_data}")

    except Exception as e:
        print(f"Error processing row {idx}: {e}")
        continue

print(f"\nExtracted {len(data)} valid rows")

# Convert to DataFrame
df = pd.DataFrame(data)

# Save to CSV in the same directory as the script
output_file = os.path.join(os.path.dirname(__file__), "vcs_extra_duty_jobs.csv")
df.to_csv(output_file, index=False)

print(f"\n✓ Exported to: {output_file}")
print(f"\nFirst 5 rows:")
print(df.head())

# Don't quit the driver - leave Chrome open for inspection
print("\nLeaving Chrome open. Close manually when done.")
# driver.quit()  # Commented out to leave browser open
